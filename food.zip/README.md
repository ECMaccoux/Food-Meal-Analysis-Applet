# Food-Query-and-Meal-Analysis
Tony Tu 
- ttu4@wisc.edu 
- X-Team 4

Eric Maccoux
- emaccoux@wisc.edu
- X-Team 10

Tanner Blanke
- tblanke2@wisc.edu
- X-Team 75

Jack Pientka
- jpientka@wisc.edu
- X-Team 42

NOTE: This program is optimized to display correctly on both the programmers' computers
and on the Linux workstations in the Computer Science building.  However, this prorgam
may experience graphical issues depending on the screen size, resolution, and scaling
settings for your computer.  The programmers have looked into solutions to this issue
and have ensured that the program as a whole does not experience any major problems
on any device.
