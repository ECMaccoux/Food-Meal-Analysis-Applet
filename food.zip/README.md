# Food-Query-and-Meal-Analysis
Tony Tu 
- ttu4@wisc.edu 
- X-Team 4

Eric Maccoux
- emaccoux@wisc.edu
- X-Team 10

Tanner Blanke
- tblanke2@wisc.edu
- X-Team 75

Jack Pientka
- jpientka@wisc.edu
- X-Team 42
